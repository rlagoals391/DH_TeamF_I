
import React from 'react';
import { Language } from '../types';

interface FestivalSectionProps {
  lang: Language;
}

const FESTIVALS = [
  {
    season: { ko: '봄 (Spring)', en: 'Spring' },
    items: [
      { ko: '낙동강 유채꽃 축제', en: 'Nakdong River Canola Festival', month: '4', desc: { ko: '국내 최대 규모의 노란 유채꽃 단지에서 즐기는 봄나들이', en: 'Enjoy spring at the nation\'s largest yellow canola field.' } },
      { ko: '부산항 축제', en: 'Busan Port Festival', month: '5', desc: { ko: '세계 5대 항만인 부산항을 배경으로 열리는 해양 문화 축제', en: 'A maritime festival at the world-class Busan Port.' } }
    ]
  },
  {
    season: { ko: '여름 (Summer)', en: 'Summer' },
    items: [
      { ko: '부산 바다 축제', en: 'Busan Sea Festival', month: '8', desc: { ko: '해운대와 광안리 등 5개 해수욕장에서 펼쳐지는 시원한 파티', en: 'Cool summer parties across Busan\'s major beaches.' } },
      { ko: '부산 국제 록 페스티벌', en: 'Busan Intl Rock Festival', month: '7-8', desc: { ko: '삼락생태공원에서 펼쳐지는 국내 최장수 록 음악 축제', en: 'Korea\'s longest-running rock festival at Samnak Park.' } }
    ]
  },
  {
    season: { ko: '가을 (Autumn)', en: 'Autumn' },
    items: [
      { ko: '부산 국제 영화제 (BIFF)', en: 'Busan Intl Film Festival', month: '10', desc: { ko: '아시아를 넘어 세계가 주목하는 영화인들의 거대한 축제', en: 'A world-renowned film festival attracting global stars.' } },
      { ko: '부산 불꽃 축제', en: 'Busan Fireworks Festival', month: '11', desc: { ko: '광안리 밤하늘을 화려하게 수놓는 초대형 멀티미디어 불꽃쇼', en: 'A spectacular multimedia fireworks show over Gwangalli.' } },
      { ko: '자갈치 축제', en: 'Jagalchi Festival', month: '10', desc: { ko: '오이소! 보이소! 사이소! 한국 최대 수산시장의 정겨운 맛', en: 'The unique taste and culture of Korea\'s largest fish market.' } }
    ]
  },
  {
    season: { ko: '겨울 (Winter)', en: 'Winter' },
    items: [
      { ko: '해운대 빛축제', en: 'Haeundae Light Festival', month: '12-1', desc: { ko: '겨울 바다와 환상적인 빛의 물결이 만나는 낭만적인 현장', en: 'Winter sea meets romantic waves of fantastic lights.' } },
      { ko: '부산 크리스마스 트리문화축제', en: 'Busan Christmas Tree Festival', month: '12', desc: { ko: '남포동 거리를 화려한 트리와 조명으로 채우는 성탄 축제', en: 'Nampo-dong street glows with magnificent Xmas lights.' } }
    ]
  }
];

const FestivalSection: React.FC<FestivalSectionProps> = ({ lang }) => {
  const title = lang === 'ko' ? '사계절 축제의 도시' : 'City of All-Season Festivals';
  
  return (
    <div className="max-w-6xl mx-auto mb-40 px-6 animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-500">
      <div className="flex items-center gap-6 mb-16">
        <h2 className="text-[12px] font-black text-slate-900 uppercase tracking-[0.4em] whitespace-nowrap">
          {title}
        </h2>
        <div className="h-px w-full bg-slate-100"></div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
        {FESTIVALS.map((f, i) => (
          <div key={i} className="group">
            <h3 className="text-[10px] font-black text-blue-600 mb-8 uppercase tracking-widest border-b-2 border-blue-50 pb-3">
              {f.season[lang]}
            </h3>
            <ul className="space-y-8">
              {f.items.map((item, idx) => (
                <li key={idx} className="flex flex-col group/item">
                  <div className="flex justify-between items-baseline mb-2">
                    <span className="text-lg font-black text-slate-900 group-hover/item:text-blue-600 transition-colors tracking-tight">
                      {item[lang]}
                    </span>
                    <span className="text-[10px] font-black text-slate-300 uppercase shrink-0 ml-2">
                      {item.month}{lang === 'ko' ? '월' : ' MO.'}
                    </span>
                  </div>
                  <p className="text-[13px] font-bold text-slate-400 leading-relaxed">
                    {item.desc[lang]}
                  </p>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FestivalSection;
