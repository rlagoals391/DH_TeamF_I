
import React, { useState, useEffect } from 'react';
import { DistrictData, Language } from '../types';

interface DistrictDetailProps {
  data: DistrictData;
  sources: Array<{ title: string; uri: string }>;
  lang: Language;
  onBack: () => void;
}

const DistrictDetail: React.FC<DistrictDetailProps> = ({ data, sources, lang, onBack }) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const ui = {
    back: lang === 'ko' ? '지도로 돌아가기' : 'Back to Map',
    michelin: lang === 'ko' ? '미슐랭 가이드 부산' : 'MICHELIN GUIDE BUSAN',
    landmark: lang === 'ko' ? '놓치면 안 될 대표 명소' : 'Top Essential Landmarks',
    eats: lang === 'ko' ? '현지 추천 맛집' : 'Recommended Local Eats',
    copy: lang === 'ko' ? '주소 복사' : 'Copy Addr.',
    copied: lang === 'ko' ? '복사 완료' : 'Copied',
    map: lang === 'ko' ? '구글 지도 보기' : 'Google Maps',
    photo: lang === 'ko' ? '현장 이미지' : 'Photos',
    menu: lang === 'ko' ? '대표 메뉴' : 'Signature',
    pro: lang === 'ko' ? 'Real Point' : 'Real Point',
    tip: lang === 'ko' ? '현지 팁' : 'Local Tip',
    foreigner: lang === 'ko' ? 'Tourist Friendly' : 'Tourist Friendly',
    reference: lang === 'ko' ? '정보 출처' : 'Sources',
    addressLabel: lang === 'ko' ? '위치 정보' : 'Location'
  };

  return (
    <div className="max-w-[1200px] mx-auto py-8 md:py-16 lg:py-20 px-6 md:px-12 lg:px-16 animate-in fade-in slide-in-from-bottom-8 duration-700 overflow-hidden relative">
      <button 
        onClick={onBack} 
        className="group mb-12 md:mb-16 flex items-center gap-4 text-slate-400 hover:text-blue-600 font-black text-[11px] md:text-[14px] uppercase tracking-[0.3em] transition-all"
      >
        <div className="w-10 h-10 md:w-12 md:h-12 rounded-full border border-slate-200 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white group-hover:border-blue-600 transition-all shadow-sm">
           <svg className="w-4 h-4 md:w-5 md:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M15 19l-7-7 7-7"/>
           </svg>
        </div>
        {ui.back}
      </button>

      <header className="mb-16 md:mb-24 lg:mb-32 relative">
        <h1 className="text-5xl md:text-7xl lg:text-[5.5rem] font-black text-slate-900 mb-6 md:mb-12 tracking-tighter leading-none break-keep overflow-wrap-anywhere">
           {data.name} 🌊
        </h1>
        <div className="max-w-4xl border-l-[8px] md:border-l-[12px] border-blue-600 pl-6 md:pl-12 py-4 md:py-6 relative">
          <p className="text-xl md:text-3xl lg:text-[2.75rem] font-black text-slate-900 mb-4 md:mb-8 leading-tight tracking-tighter italic break-keep">
            "{data.motto}"
          </p>
          <p className="text-sm md:text-lg lg:text-xl text-slate-500 font-bold leading-relaxed tracking-tight break-keep max-w-3xl">
            {data.aiSummary}
          </p>
        </div>
      </header>

      {/* Michelin Section */}
      {data.michelin && data.michelin.length > 0 && (
        <section className="mb-20 md:mb-32 lg:mb-40 bg-[#8B2222] p-8 md:p-14 lg:p-16 rounded-[30px] md:rounded-[60px] relative overflow-hidden shadow-2xl">
          <div className="flex items-center gap-4 md:gap-8 mb-10 md:mb-16 relative z-10">
             <div className="w-12 h-12 md:w-16 md:h-16 bg-white rounded-xl md:rounded-2xl flex items-center justify-center text-[#8B2222] shadow-xl">
                <svg className="w-8 h-8 md:w-10 md:h-10" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
             </div>
             <div>
                <h2 className="text-white text-[10px] md:text-[16px] font-black uppercase tracking-[0.4em] mb-1">{ui.michelin}</h2>
                <div className="h-1 w-20 md:w-32 bg-white/30 rounded-full"></div>
             </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 relative z-10">
            {data.michelin.map((m, i) => (
              <div key={i} className="p-8 md:p-10 bg-white rounded-[32px] md:rounded-[48px] flex flex-col shadow-xl transition-all hover:scale-[1.02] group">
                <div className="flex justify-between items-start mb-6">
                  <div className={`px-4 py-1 text-[9px] md:text-[11px] font-black rounded-full uppercase tracking-widest ${m.type.includes('Star') ? 'bg-[#8B2222] text-white' : 'bg-slate-900 text-white'}`}>
                    {m.type}
                  </div>
                  <a href={m.photoSearchUrl} target="_blank" rel="noreferrer" className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-400 hover:text-[#8B2222] transition-all border border-slate-100">
                     <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2 2 2 0 002 2z"/></svg>
                  </a>
                </div>
                <h3 className="text-2xl md:text-3xl font-black text-slate-900 mb-4 tracking-tighter leading-tight break-keep">{m.name}</h3>
                <p className="text-sm md:text-base text-slate-500 font-bold mb-8 flex-grow leading-relaxed italic break-keep">"{m.description}"</p>
                
                {m.foreignerInfo && (
                  <div className="mb-6 relative p-5 bg-slate-900 rounded-[24px] text-white shadow-lg border border-slate-800">
                    <span className="text-[8px] md:text-[10px] font-black uppercase tracking-[0.2em] bg-white/10 px-2 py-0.5 rounded-md text-slate-300 block mb-2 w-fit">{ui.foreigner}</span>
                    <p className="text-[13px] md:text-[15px] font-black leading-snug break-keep text-slate-100">{m.foreignerInfo}</p>
                  </div>
                )}

                <div className="mb-6 pt-6 border-t border-slate-100">
                   <p className="text-[9px] md:text-[11px] font-black text-slate-300 uppercase mb-2">{ui.menu}</p>
                   <p className="text-lg md:text-xl font-black text-slate-900 uppercase tracking-tight break-keep">{m.signature}</p>
                </div>

                <div className="mt-auto pt-6 border-t border-slate-50 flex flex-col gap-4">
                  <div>
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1 block">{ui.addressLabel}</span>
                    <p className="text-[13px] md:text-[15px] font-bold text-slate-600 leading-tight break-keep">{m.address}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <a href={m.mapUrl} target="_blank" rel="noreferrer" className="py-4 bg-[#8B2222] text-white rounded-[20px] text-[10px] font-black uppercase tracking-widest hover:bg-slate-900 transition-all text-center">
                      {ui.map}
                    </a>
                    <button 
                      onClick={() => {
                        navigator.clipboard.writeText(m.address);
                        setCopiedId(`michelin-${i}`);
                        setTimeout(() => setCopiedId(null), 2000);
                      }}
                      className="py-4 bg-slate-900 text-white rounded-[20px] text-[10px] font-black uppercase tracking-widest hover:bg-[#8B2222] transition-all text-center"
                    >
                      {copiedId === `michelin-${i}` ? ui.copied : ui.copy}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {[ 
        {title: ui.landmark, items: data.landmarks, color: 'blue', bg: 'bg-blue-50/20', border: 'border-blue-100', icon: '⚓'}, 
        {title: ui.eats, items: data.foods, color: 'emerald', bg: 'bg-emerald-50/20', border: 'border-emerald-100', icon: '⛵'} 
      ].map((sec, idx) => (
        <section key={idx} className={`mb-20 md:mb-32 p-8 md:p-14 lg:p-16 rounded-[30px] md:rounded-[60px] border ${sec.border} ${sec.bg}`}>
          <div className="flex items-center gap-6 mb-12 md:mb-16">
             <h2 className={`text-[11px] md:text-[16px] font-black text-${sec.color}-600 uppercase tracking-[0.4em] md:tracking-[0.5em] whitespace-nowrap`}>
              {sec.icon} {sec.title}
             </h2>
             <div className={`h-px w-full bg-${sec.color}-200`}></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {sec.items.map((item, i) => (
              <div key={i} className="bg-white p-8 md:p-10 rounded-[32px] md:rounded-[48px] border border-slate-100 shadow-sm flex flex-col transition-all hover:shadow-2xl group">
                <div className="flex justify-between items-start mb-8">
                  <h3 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tighter leading-tight pr-4 group-hover:text-blue-600 transition-colors break-keep">
                    {item.name}
                  </h3>
                  <a href={item.photoSearchUrl} target="_blank" rel="noreferrer" className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-slate-50 flex items-center justify-center text-slate-400 hover:text-blue-600 transition-all border border-slate-100 shrink-0">
                    <svg className="w-5 h-5 md:w-7 md:h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2 2 2 0 002 2z"/></svg>
                  </a>
                </div>
                
                <p className="text-sm md:text-base text-slate-500 font-bold leading-relaxed mb-10 flex-grow tracking-tight break-keep">
                  {item.description}
                </p>

                <div className="space-y-4 mb-10">
                  <div className={`relative p-6 bg-${sec.color}-600 rounded-[24px] md:rounded-[32px] text-white shadow-lg`}>
                    <span className="text-[9px] md:text-[11px] font-black uppercase tracking-[0.2em] bg-white/20 px-2 py-0.5 rounded-md block mb-2 w-fit">{ui.pro}</span>
                    <p className="font-black text-lg md:text-xl leading-tight tracking-tight break-keep">{item.pos}</p>
                  </div>

                  {item.foreignerInfo && (
                    <div className="relative p-6 bg-slate-900 rounded-[24px] md:rounded-[32px] text-white shadow-lg border border-slate-800">
                      <span className="text-[9px] md:text-[11px] font-black uppercase tracking-[0.2em] bg-white/10 px-2 py-0.5 rounded-md text-slate-300 block mb-2 w-fit">{ui.foreigner}</span>
                      <p className="font-black text-base md:text-lg leading-snug tracking-tight break-keep text-slate-100">{item.foreignerInfo}</p>
                    </div>
                  )}
                  
                  <div className="p-6 bg-slate-50 rounded-[24px] md:rounded-[32px] border border-slate-200">
                    <span className="text-[9px] md:text-[11px] font-black uppercase tracking-[0.2em] text-slate-400 block mb-2">{ui.tip}</span>
                    <p className="font-bold text-sm md:text-base leading-snug text-slate-800 tracking-tight break-keep">{item.neg}</p>
                  </div>
                </div>

                <div className="mt-auto pt-8 border-t border-slate-50 flex flex-col gap-6">
                  <div>
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1 block">{ui.addressLabel}</span>
                    <p className="text-[13px] md:text-[15px] font-bold text-slate-600 leading-tight break-keep">{item.address}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <a href={item.mapUrl} target="_blank" rel="noreferrer" className="py-4 bg-slate-100 text-slate-600 rounded-2xl text-[11px] font-black uppercase tracking-widest hover:bg-blue-600 hover:text-white transition-all text-center">
                      {ui.map}
                    </a>
                    <button 
                      onClick={() => {
                        navigator.clipboard.writeText(item.address);
                        setCopiedId(`${idx}-${i}`);
                        setTimeout(() => setCopiedId(null), 2000);
                      }}
                      className="py-4 bg-slate-900 text-white rounded-2xl text-[11px] font-black uppercase tracking-widest hover:bg-blue-600 transition-all text-center"
                    >
                      {copiedId === `${idx}-${i}` ? ui.copied : ui.copy}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      ))}

      <footer className="pt-20 border-t border-slate-100 opacity-40 pb-20 text-center relative overflow-hidden">
         <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-blue-200 to-transparent"></div>
         <h4 className="text-[10px] md:text-[13px] font-black text-slate-400 uppercase tracking-[0.6em] mb-12">{ui.reference}</h4>
         <div className="flex flex-wrap gap-x-10 gap-y-6 justify-center px-4">
           {sources.map((s, i) => (
             <a key={i} href={s.uri} target="_blank" rel="noreferrer" className="text-[12px] md:text-[15px] font-black uppercase tracking-widest hover:text-blue-600 transition-all underline decoration-slate-200 underline-offset-[12px] decoration-2">{s.title}</a>
           ))}
         </div>
      </footer>
    </div>
  );
};

export default DistrictDetail;
