
import React, { useState } from 'react';
import { Language } from '../types';

interface CourseSectionProps {
  lang: Language;
}

interface SpotDetail {
  name: string;
  desc: string;
}

interface CourseDetail {
  ko: { 
    title: string; 
    tag: string; 
    desc: string;
    spots: SpotDetail[];
    proTip: string;
    duration: string;
    transport: string;
  };
  en: { 
    title: string; 
    tag: string; 
    desc: string;
    spots: SpotDetail[];
    proTip: string;
    duration: string;
    transport: string;
  };
  color: string;
  icon: string;
}

const COURSES: CourseDetail[] = [
  {
    ko: { 
      title: 'K-푸드 챌린지 코스', 
      tag: 'Foodie', 
      desc: '비프광장 호떡부터 미슐랭 식당까지, 한국의 매운맛과 정을 느낍니다.',
      spots: [
        { name: 'BIFF 광장', desc: '부산 길거리 음식 문화의 발상지이자 씨앗호떡의 성지입니다.' },
        { name: '자갈치 시장', desc: '활기 넘치는 한국 최대 규모의 수산시장으로 싱싱한 회를 즐길 수 있습니다.' },
        { name: '남포동 포장마차', desc: '밤이면 펼쳐지는 포장마차 거리에서 부산의 낭만적인 밤을 경험하세요.' }
      ],
      proTip: '씨앗호떡은 줄이 길어도 금방 줄어듭니다. 포장마차는 현금이나 계좌이체가 편리해요!',
      duration: '약 4~5시간',
      transport: '지하철 1호선 자갈치역/남포역'
    },
    en: { 
      title: 'K-Food Challenge', 
      tag: 'Foodie', 
      desc: 'From street Hotteok to Michelin stars, taste the real Korea.',
      spots: [
        { name: 'BIFF Square', desc: 'The birthplace of street food culture and the mecca of Seed Hotteok.' },
        { name: 'Jagalchi Market', desc: "Korea's largest seafood market filled with energy and fresh sashimi." },
        { name: 'Nampo-dong Stalls', desc: 'Experience the romantic night of Busan at the street food tent area.' }
      ],
      proTip: 'Seed Hotteok lines move fast. Street stalls prefer cash or bank transfers.',
      duration: '4-5 Hours',
      transport: 'Metro Line 1 (Jagalchi/Nampo Station)'
    },
    color: 'bg-orange-600',
    icon: '🥘'
  },
  {
    ko: { 
      title: '블루 힐링 바다 산책', 
      tag: 'Relax', 
      desc: '해운대 블루라인파크와 해변 열차를 타고 즐기는 끝없는 수평선 여행.',
      spots: [
        { name: '해운대 해수욕장', desc: '부산을 상징하는 드넓은 백사장과 시원한 바다를 만끽하세요.' },
        { name: '미포 철길', desc: '옛 해안 기찻길을 따라 걷는 절경 산책로로 인생샷 명소입니다.' },
        { name: '청사포 다릿돌 전망대', desc: '푸른 파도 위 투명한 바닥이 주는 스릴과 탁 트인 조망이 일품입니다.' }
      ],
      proTip: '해변열차는 일몰 1시간 전에 타는 것을 강력 추천합니다. 예약은 필수예요!',
      duration: '약 3시간',
      transport: '해운대 블루라인파크'
    },
    en: { 
      title: 'Ocean View Healing', 
      tag: 'Relax', 
      desc: 'A serene journey along the coast with endless horizons and sea breezes.',
      spots: [
        { name: 'Haeundae Beach', desc: "Busan's iconic beach with a wide horizon and refreshing breeze." },
        { name: 'Mipo Railway', desc: 'A scenic walking trail along the old coastal railroad, perfect for photos.' },
        { name: 'Cheongsapo Skywalk', desc: 'A transparent floor above the crashing blue waves with stunning views.' }
      ],
      proTip: 'Book the sunset train 1 hour before golden hour. Reservations are essential.',
      duration: '3 Hours',
      transport: 'Haeundae Blue Line Park'
    },
    color: 'bg-blue-600',
    icon: '🌊'
  },
  {
    ko: { 
      title: 'MZ 힙 플레이스 투어', 
      tag: 'Trendy', 
      desc: '전포 카페거리의 감성과 광안리의 화려한 야경을 담는 인스타 명소 투어.',
      spots: [
        { name: '전포 카페거리', desc: '공구 상가에서 트렌디한 카페 거리로 변신한 감성 가득한 골목입니다.' },
        { name: '광안리 해수욕장', desc: '광안대교 뷰와 화려한 야경, 그리고 드론쇼가 펼쳐지는 명소입니다.' },
        { name: '민락 수변공원', desc: '노을을 보며 가볍게 산책하거나 로컬 감성을 느끼기 좋은 쉼터입니다.' }
      ],
      proTip: '전포동 카페들은 월요일 휴무가 많으니 확인 필수! 광안리 드론쇼 시간도 꼭 체크하세요.',
      duration: '약 6시간',
      transport: '지하철 2호선 전포역/광안역'
    },
    en: { 
      title: 'MZ Hipster Tour', 
      tag: 'Trendy', 
      desc: 'Instagrammable spots from Jeonpo cafe streets to Gwangalli night views.',
      spots: [
        { name: 'Jeonpo Cafe Street', desc: 'Trendy cafes filled with unique vibes in a transformed industrial alley.' },
        { name: 'Gwangalli Beach', desc: 'The best spot for the bridge view, night lights, and the drone show.' },
        { name: 'Millak Waterside Park', desc: 'A local favorite spot for sunset and enjoying the ocean breeze.' }
      ],
      proTip: 'Many Jeonpo cafes close on Mondays. Check the Gwangalli drone show schedule!',
      duration: '6 Hours',
      transport: 'Metro Line 2 (Jeonpo/Gwangalli Station)'
    },
    color: 'bg-purple-600',
    icon: '✨'
  }
];

const CourseSection: React.FC<CourseSectionProps> = ({ lang }) => {
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);

  const ui = {
    sectionTitle: lang === 'ko' ? '추천 여행 테마 🌊' : 'Top Travel Themes 🌊',
    guideHint: lang === 'ko' ? '클릭하여 상세 정보 보기' : 'Click to see details',
    close: lang === 'ko' ? '닫기' : 'Close',
    spots: lang === 'ko' ? '방문 스팟 상세 (클릭 시 지도 이동) 📍' : 'Spot Details (Click for Map) 📍',
    proTip: lang === 'ko' ? '현지 전문가 꿀팁 ⚓' : 'Local Pro Tip ⚓',
    duration: lang === 'ko' ? '예상 소요 시간' : 'Estimated Duration',
    transport: lang === 'ko' ? '추천 교통수단' : 'Recommended Transit',
  };

  const selectedCourse = selectedIdx !== null ? COURSES[selectedIdx] : null;

  const getGoogleMapUrl = (name: string) => {
    // 쿼리 정확도를 높이기 위해 'Busan' 키워드를 강력 결합
    const query = encodeURIComponent(`${name} Busan`);
    return `https://www.google.com/maps/search/?api=1&query=${query}`;
  };

  return (
    <div className="max-w-5xl mx-auto mb-40 px-4 relative">
      <div className="absolute top-0 right-0 -z-10 opacity-5 pointer-events-none">
        <svg width="400" height="400" viewBox="0 0 400 400">
          <path d="M0,100 C100,50 200,150 400,100 L400,400 L0,400 Z" fill="#2563eb" />
        </svg>
      </div>

      <div className="flex items-center gap-6 mb-12">
        <h2 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.5em] whitespace-nowrap flex items-center gap-2">
          {ui.sectionTitle}
        </h2>
        <div className="h-px w-full bg-slate-100"></div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {COURSES.map((c, i) => (
          <div 
            key={i} 
            onClick={() => setSelectedIdx(i)}
            className="group relative p-10 bg-slate-900 rounded-[50px] shadow-xl hover:shadow-[0_30px_60px_rgba(37,99,235,0.2)] hover:scale-[1.02] transition-all duration-500 cursor-pointer overflow-hidden flex flex-col"
          >
            <div className={`absolute top-0 right-0 w-32 h-32 ${c.color} opacity-10 blur-3xl rounded-full transition-opacity group-hover:opacity-30`}></div>
            
            <div className="relative z-10">
              <div className="flex justify-between items-start mb-6">
                <span className={`inline-block px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${c.color} text-white`}>
                  {c[lang].tag}
                </span>
                <span className="text-3xl filter drop-shadow-md group-hover:scale-125 transition-transform duration-500">
                  {c.icon}
                </span>
              </div>
              
              <h3 className="text-2xl font-black text-white mb-4 tracking-tighter leading-tight group-hover:text-blue-400 transition-colors">
                {c[lang].title}
              </h3>
              
              <p className="text-slate-400 text-sm font-bold mb-8 leading-relaxed">
                {c[lang].desc}
              </p>

              <div className="mt-4 flex flex-col items-center">
                 <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest animate-pulse">
                   {ui.guideHint}
                 </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal Overlay */}
      {selectedCourse && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-4 md:p-12 animate-in fade-in duration-300">
          <div 
            className="absolute inset-0 bg-slate-900/80 backdrop-blur-2xl"
            onClick={() => setSelectedIdx(null)}
          ></div>
          
          <div className="relative w-full max-w-4xl bg-white rounded-[40px] md:rounded-[60px] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-500">
            {/* Modal Header Decoration */}
            <div className={`h-40 md:h-60 ${selectedCourse.color} flex items-center justify-center relative`}>
               <span className="text-7xl md:text-9xl filter drop-shadow-2xl animate-bounce">
                  {selectedCourse.icon}
               </span>
               <button 
                onClick={() => setSelectedIdx(null)}
                className="absolute top-6 right-6 md:top-10 md:right-10 w-10 h-10 md:w-14 md:h-14 bg-black/10 hover:bg-black/30 text-white rounded-full flex items-center justify-center transition-all backdrop-blur-md border border-white/20"
               >
                 <svg className="w-5 h-5 md:w-7 md:h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12"/></svg>
               </button>
            </div>

            {/* Modal Body */}
            <div className="p-8 md:p-14 lg:p-16 max-h-[70vh] overflow-y-auto custom-scrollbar">
              <div className="mb-12">
                <span className={`inline-block px-4 py-1.5 rounded-full text-[10px] md:text-[12px] font-black uppercase tracking-[0.2em] mb-4 ${selectedCourse.color} text-white`}>
                  {selectedCourse[lang].tag}
                </span>
                <h2 className="text-4xl md:text-6xl font-black text-slate-900 tracking-tighter leading-tight break-keep">
                  {selectedCourse[lang].title}
                </h2>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 lg:gap-16">
                {/* Left: Spots List */}
                <div className="lg:col-span-3 space-y-10">
                  <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-3 flex items-center gap-2">
                    {ui.spots}
                  </h4>
                  <div className="space-y-8">
                    {selectedCourse[lang].spots.map((spot, idx) => (
                      <div key={idx} className="group/item flex gap-6">
                        <div className={`w-10 h-10 rounded-2xl ${selectedCourse.color} text-white flex items-center justify-center font-black shrink-0 shadow-lg`}>
                          {idx + 1}
                        </div>
                        <div>
                          <a 
                            href={getGoogleMapUrl(spot.name)} 
                            target="_blank" 
                            rel="noreferrer"
                            className="inline-flex items-center gap-2 text-xl md:text-2xl font-black text-slate-900 mb-2 group-hover/item:text-blue-600 transition-all border-b-2 border-slate-100 hover:border-blue-600"
                          >
                            {spot.name}
                            <svg className="w-4 h-4 text-slate-300 group-hover/item:text-blue-600 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                            </svg>
                          </a>
                          <p className="text-sm md:text-base text-slate-500 font-bold leading-relaxed break-keep">
                            {spot.desc}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Right: Pro Tips & Transit */}
                <div className="lg:col-span-2 space-y-10">
                  <div className="bg-slate-50 p-8 md:p-10 rounded-[40px] border border-slate-100 shadow-inner relative overflow-hidden">
                    <div className="absolute top-0 right-0 text-6xl opacity-5 translate-x-4 -translate-y-4">⚓</div>
                    <h4 className="text-[11px] font-black text-blue-600 uppercase tracking-widest mb-4">
                      {ui.proTip}
                    </h4>
                    <p className="text-[15px] md:text-[17px] text-slate-700 font-bold leading-relaxed break-keep">
                       {selectedCourse[lang].proTip}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 gap-5">
                    <div className="flex items-center gap-5 p-6 bg-white border border-slate-100 rounded-[24px] shadow-sm hover:border-blue-200 transition-colors">
                       <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center text-blue-600 shrink-0">
                          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                       </div>
                       <div>
                          <span className="text-[10px] font-black text-slate-400 uppercase block mb-1">{ui.duration}</span>
                          <span className="text-[15px] md:text-[17px] font-black text-slate-900">{selectedCourse[lang].duration}</span>
                       </div>
                    </div>
                    <div className="flex items-center gap-5 p-6 bg-white border border-slate-100 rounded-[24px] shadow-sm hover:border-emerald-200 transition-colors">
                       <div className="w-12 h-12 rounded-2xl bg-emerald-50 flex items-center justify-center text-emerald-600 shrink-0">
                          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                       </div>
                       <div>
                          <span className="text-[10px] font-black text-slate-400 uppercase block mb-1">{ui.transport}</span>
                          <span className="text-[15px] md:text-[17px] font-black text-slate-900">{selectedCourse[lang].transport}</span>
                       </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-10 border-t border-slate-50 bg-slate-50/50 flex justify-center">
              <button 
                onClick={() => setSelectedIdx(null)}
                className="px-16 py-5 bg-slate-900 text-white rounded-full text-[12px] md:text-[14px] font-black uppercase tracking-[0.4em] hover:bg-blue-600 transition-all shadow-2xl active:scale-95"
              >
                {ui.close}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CourseSection;
