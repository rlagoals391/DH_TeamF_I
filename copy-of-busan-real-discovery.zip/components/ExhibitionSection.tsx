
import React from 'react';
import { Language } from '../types';

interface ExhibitionSectionProps {
  lang: Language;
}

const EVENTS = [
  {
    ko: { 
      title: '부산 시립 미술관 소장품 기획전', 
      place: '부산시립미술관 (BMA)', 
      type: '미술 전시',
      desc: '부산의 근현대 미술사를 관통하는 핵심 소장품을 통해 지역 예술의 깊이 있는 서사를 탐구합니다.'
    },
    en: { 
      title: 'BMA Collection Special Exhibit', 
      place: 'Busan Museum of Art', 
      type: 'Art Exhibit',
      desc: 'Exploring deep narratives of local art through core collections that define Busan\'s modern art history.'
    },
    tag: 'Art',
    color: 'bg-indigo-600',
    url: 'https://art.busan.go.kr/'
  },
  {
    ko: { 
      title: 'F1963 현대 미술 메가 프로젝트', 
      place: 'F1963 석천홀', 
      type: '융복합 전시',
      desc: '산업 시설에서 문화 공간으로 탈바꿈한 독특한 아우라 속에서 실험적인 현대 예술가들의 작품을 만납니다.'
    },
    en: { 
      title: 'F1963 Mega Art Project', 
      place: 'F1963 Cultural Complex', 
      type: 'Modern Art',
      desc: 'Experience experimental works by contemporary artists within the unique aura of a renovated wire factory.'
    },
    tag: 'Culture',
    color: 'bg-rose-600',
    url: 'http://www.f1963.org/'
  },
  {
    ko: { 
      title: '부산 문화 회관 기획 연주회', 
      place: '부산문화회관 대극장', 
      type: '클래식 공연',
      desc: '세계적인 지휘자와 협연자들이 선사하는 웅장하고 격조 높은 정통 클래식 선율을 경험하세요.'
    },
    en: { 
      title: 'Busan Cultural Concert Series', 
      place: 'Busan Cultural Center', 
      type: 'Classic',
      desc: 'Experience grand and sophisticated classical melodies presented by world-class conductors and soloists.'
    },
    tag: 'Music',
    color: 'bg-amber-600',
    url: 'https://www.bscc.or.kr/'
  }
];

const ExhibitionSection: React.FC<ExhibitionSectionProps> = ({ lang }) => {
  const title = lang === 'ko' ? '지금 부산의 문화' : 'Busan Cultural Now';

  return (
    <div className="max-w-5xl mx-auto mb-40 px-4">
      <div className="flex items-center gap-6 mb-16">
        <h2 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.5em] whitespace-nowrap">
          {title}
        </h2>
        <div className="h-px w-full bg-slate-100"></div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {EVENTS.map((e, i) => (
          <a 
            key={i}
            href={e.url}
            target="_blank"
            rel="noreferrer"
            className="group p-10 bg-white border border-slate-100 rounded-[50px] hover:border-blue-600 hover:shadow-3xl hover:-translate-y-2 transition-all duration-700 flex flex-col"
          >
            <div className="flex items-center gap-3 mb-8">
              <span className={`px-3 py-1.5 ${e.color} text-white text-[9px] font-black rounded-full uppercase tracking-widest`}>
                {e.tag}
              </span>
              <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">
                {e[lang].type}
              </span>
            </div>
            <h3 className="text-2xl font-black text-slate-900 mb-4 tracking-tight group-hover:text-blue-600 transition-colors leading-tight">
              {e[lang].title}
            </h3>
            <p className="text-[14px] font-bold text-slate-400 leading-relaxed mb-10 flex-grow">
              {e[lang].desc}
            </p>
            <div className="pt-8 border-t border-slate-50 flex items-center justify-between">
              <span className="text-[12px] font-black text-slate-900">{e[lang].place}</span>
              <div className="w-8 h-8 rounded-full bg-slate-50 group-hover:bg-blue-600 group-hover:text-white flex items-center justify-center transition-all">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M14 5l7 7-7 7"/></svg>
              </div>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
};

export default ExhibitionSection;
