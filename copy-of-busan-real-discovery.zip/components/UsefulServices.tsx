
import React from 'react';
import { Language } from '../types';

interface UsefulServicesProps {
  lang: Language;
}

const SERVICES = [
  {
    id: 'citytour',
    ko: { title: '부산 시티투어', desc: '주요 명소를 가장 편안하게 돌아보는 2층 테마 버스', action: '예약 사이트' },
    en: { title: 'City Tour Bus', desc: 'The most comfortable way to visit key spots via theme buses.', action: 'Official Site' },
    url: 'https://www.citytourbusan.com/',
    color: 'bg-blue-600'
  },
  {
    id: 'busanpass',
    ko: { title: '비짓 부산 패스', desc: '주요 유료 명소 무료 입장과 교통 카드 혜택의 올인원 패스', action: '패스 구매' },
    en: { title: 'Visit Busan Pass', desc: 'All-in-one pass with free entry to major spots & transit.', action: 'Get Pass' },
    url: 'https://www.visitbusanpass.com/',
    color: 'bg-slate-900'
  },
  {
    id: 'dynamic',
    ko: { title: '비짓 부산 공식', desc: '부산시가 운영하는 공신력 있는 공식 관광 포털 서비스', action: '정보 포털' },
    en: { title: 'Visit Busan Official', desc: 'The city\'s official, authoritative tourism info portal.', action: 'Explore Portal' },
    url: 'https://www.visitbusan.net/',
    color: 'bg-emerald-600'
  }
];

const UsefulServices: React.FC<UsefulServicesProps> = ({ lang }) => {
  const sectionTitle = lang === 'ko' ? '여행 필수 유틸리티' : 'Travel Essentials';

  return (
    <div className="max-w-5xl mx-auto mb-20 px-4 animate-in fade-in slide-in-from-bottom-4 duration-1000 delay-300">
      <div className="flex items-center gap-6 mb-12">
        <h2 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.5em] whitespace-nowrap">
          {sectionTitle}
        </h2>
        <div className="h-px w-full bg-slate-100"></div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {SERVICES.map((s) => (
          <a 
            key={s.id}
            href={s.url}
            target="_blank"
            rel="noreferrer"
            className="group block p-10 bg-white border border-slate-100 rounded-[50px] hover:shadow-4xl hover:shadow-slate-200/50 transition-all duration-700"
          >
            <div className={`w-12 h-12 ${s.color} rounded-2xl mb-8 flex items-center justify-center text-white transition-all group-hover:rotate-6 group-hover:scale-110 shadow-lg`}>
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </div>
            <h3 className="text-2xl font-black text-slate-900 mb-3 tracking-tight group-hover:text-blue-600 transition-colors">
              {s[lang].title}
            </h3>
            <p className="text-sm font-bold text-slate-400 leading-relaxed mb-8">
              {s[lang].desc}
            </p>
            <div className="flex items-center gap-3">
               <span className="text-[11px] font-black uppercase tracking-widest text-slate-900 border-b-2 border-slate-900 pb-1 group-hover:text-blue-600 group-hover:border-blue-600 transition-all">
                 {s[lang].action}
               </span>
               <svg className="w-4 h-4 text-slate-300 group-hover:text-blue-600 group-hover:translate-x-1 transition-all" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7"/></svg>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
};

export default UsefulServices;
