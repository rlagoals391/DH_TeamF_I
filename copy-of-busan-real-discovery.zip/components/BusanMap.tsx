
import React from 'react';
import { BUSAN_DISTRICTS } from '../constants';
import { Language } from '../types';

interface BusanMapProps {
  onDistrictClick: (id: string) => void;
  lang: Language;
}

const BusanMap: React.FC<BusanMapProps> = ({ onDistrictClick, lang }) => {
  return (
    <div className="w-full max-w-4xl mx-auto relative overflow-hidden group/map">
      <svg viewBox="0 0 1000 1000" className="w-full h-auto drop-shadow-xl relative z-0">
        <defs>
          <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="15" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
          <linearGradient id="nodeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="100%" stopColor="#f8fafc" />
          </linearGradient>
        </defs>

        <path 
          d="M200,600 L380,550 M380,550 L520,560 M520,560 L680,580 M680,580 L780,520 M780,520 L850,300" 
          stroke="#cbd5e1" 
          strokeWidth="1.5" 
          strokeDasharray="8,8"
          fill="none" 
          className="opacity-40"
        />
        
        {BUSAN_DISTRICTS.map((dist) => (
          <g 
            key={dist.id} 
            className="group cursor-pointer outline-none"
            onClick={(e) => {
              e.stopPropagation();
              onDistrictClick(dist.id); // ID 직접 전달로 오류 방지
            }}
          >
            <circle
              cx={dist.x}
              cy={dist.y}
              r={dist.size + 15}
              className="fill-blue-400/0 transition-all duration-700 group-hover:fill-blue-400/20"
              filter="url(#glow)"
            />
            <circle
              cx={dist.x}
              cy={dist.y}
              r={dist.size}
              className="fill-white/90 stroke-slate-200 stroke-1 transition-all duration-500 group-hover:stroke-blue-400 group-hover:scale-105"
              style={{ transformOrigin: `${dist.x}px ${dist.y}px`, backdropFilter: 'blur(4px)' }}
            />
            <circle
              cx={dist.x}
              cy={dist.y}
              r={dist.size - 8}
              fill="url(#nodeGradient)"
              className="stroke-slate-100 stroke-1 transition-all duration-300 group-hover:fill-blue-600 group-hover:stroke-blue-500"
              style={{ transformOrigin: `${dist.x}px ${dist.y}px` }}
            />
            <text
              x={dist.x}
              y={dist.y}
              className="text-[25px] md:text-[32px] font-black fill-slate-500 pointer-events-none group-hover:fill-white transition-all duration-300 tracking-tighter"
              textAnchor="middle"
              dominantBaseline="middle"
            >
              {lang === 'ko' ? dist.nameKo : dist.nameEn}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
};

export default BusanMap;
