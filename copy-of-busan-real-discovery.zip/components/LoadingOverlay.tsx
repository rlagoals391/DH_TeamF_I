
import React, { useState, useEffect } from 'react';
import { Language } from '../types';

interface LoadingOverlayProps {
  districtName: string;
  lang: Language;
}

const TRIVIA_KO = [
  "부산은 한국전쟁 당시 1,023일 동안 대한민국의 임시 수도였습니다.",
  "밀면은 전쟁 중 메밀 대신 구호 물자인 밀가루로 만든 부산만의 냉면입니다.",
  "돼지국밥은 피란 시절 배고픔을 달래주던 부산의 대표적인 소울푸드입니다.",
  "영도대교는 한국 유일의 도개교로, 피란민들이 다시 만나기로 약속했던 장소입니다.",
  "감천문화마을은 산자락을 따라 계단식으로 집들이 늘어선 '한국의 산토리니'입니다.",
  "보수동 책방골목은 전쟁 당시 피란민들이 가져온 책을 팔며 형성된 유서 깊은 거리입니다.",
  "산복도로는 산등성이를 따라 굽이굽이 이어지는 부산만의 독특한 풍경입니다.",
  "송도 해수욕장은 1913년에 개장한 대한민국 최초의 공설 해수욕장입니다.",
  "태종대는 파도의 침식으로 만들어진 기암괴석이 장관을 이루는 해안 절벽입니다.",
  "범어사는 신라 시대에 창건된 천년 고찰로 부산을 대표하는 사찰입니다.",
  "오륙도는 조석에 따라 섬이 5개 또는 6개로 보인다고 하여 붙여진 이름입니다.",
  "부산항은 세계 10대 컨테이너 항만 중 하나로 한국 수출의 심장입니다.",
  "낙동강 하구는 세계적인 철새 도래지로 생태적 가치가 매우 높습니다.",
  "광안대교는 총 길이 7.42km로 한국 최대 규모의 현수교입니다.",
  "자갈치 시장의 이름은 옛날 이곳에 '자갈'이 많았다고 하여 붙여졌습니다.",
  "부산 국제 영화제(BIFF)는 아시아 최대 규모의 영화 축제입니다.",
  "해운대 엘시티(LCT)는 411m 높이로 한국에서 두 번째로 높은 마천루입니다.",
  "부산의 사투리는 15세기 중세 한국어의 성조 특징이 일부 남아있습니다.",
  "누리마루 APEC 하우스는 2005년 제13차 APEC 정상회의가 열린 역사적인 장소입니다.",
  "가덕도 등대는 1909년에 점등된 서구식 근대 건축물로 역사적 가치가 큽니다.",
  "부산의 UN기념공원은 세계에서 유일한 UN군 묘지입니다.",
  "금정산성은 전체 길이가 약 18.8km에 달하는 한국에서 가장 큰 산성입니다.",
  "동래파전은 조선 시대 동래부사가 임금님께 진상하던 귀한 음식었습니다.",
  "부산 도시철도 1호선은 1985년 개통된 지방 최초의 지하철입니다.",
  "초량 이바구길은 일제강점기부터 전쟁 이후까지 부산의 근현대사를 품고 있습니다.",
  "흰여울문화마을은 영화 '변호인'의 촬영지로 유명하며 절벽 끝 바다 조망이 일품입니다.",
  "부산 해운대구는 전국에서 유일하게 두 개의 해수욕장(해운대, 송정)을 품고 있습니다.",
  "부산항 대교는 밤이 되면 시시각각 변하는 화려한 조명으로 야경 명소가 되었습니다.",
  "해동용궁사는 바닷가 절벽 위에 세워진 한국에서 가장 아름다운 사찰 중 하나입니다.",
  "부산역 앞 차이나타운은 구한말 청나라 영사관이 있던 자리에서 시작되었습니다.",
  "용두산공원의 부산타워는 120m 높이에서 원도심의 정취를 한눈에 볼 수 있습니다."
];

const TRIVIA_EN = [
  "Busan served as the provisional capital of South Korea for 1,023 days during the Korean War.",
  "Milmyeon is a unique Busan noodle dish created using flour instead of buckwheat during the war.",
  "Dwaeji-gukbap (pork soup) is Busan's soul food that comforted hungry refugees during the war.",
  "Yeongdo Bridge is Korea's only bascule bridge, once a landmark for reunited refugees.",
  "Gamcheon Culture Village is known as the 'Santorini of Korea' with colorful houses on hills.",
  "Bosu-dong Book Alley was formed by refugees selling books to survive during the war.",
  "San복-ro (mountainside roads) offer unique winding landscapes along the city's ridges.",
  "Songdo Beach, opened in 1913, is the first public beach in South Korea.",
  "Taejongdae is a coastal cliff featuring spectacular rock formations carved by the waves.",
  "Beomeosa is a thousand-year-old temple founded during the Silla Dynasty.",
  "Oryukdo Islands are named so because they appear as 5 or 6 islands depending on the tide.",
  "Busan Port is one of the world's top 10 container ports and the heart of Korea's exports.",
  "The Nakdong River Estuary is a world-renowned habitat for migratory birds.",
  "Gwangandaegyo is the largest suspension bridge in Korea, stretching 7.42km.",
  "Jagalchi Market's name originates from 'Jagal' (gravel) that once covered the shore.",
  "Busan International Film Festival (BIFF) is the largest film festival in Asia.",
  "Haeundae LCT, at 411m, is the second-tallest building in South Korea.",
  "The Busan dialect retains some pitch accent characteristics of 15th-century Korean.",
  "Nurimaru APEC House is the historic site where the 13th APEC Summit was held in 2005.",
  "Gadeokdo Lighthouse is a Western-style modern building lit in 1909.",
  "The UN Memorial Cemetery in Busan is the only UN cemetery in the world.",
  "Geumjeongsanseong is the largest mountain fortress in Korea, about 18.8km long.",
  "Dongrae Pajeon was a precious dish presented to the king during the Joseon Dynasty.",
  "The Busan Metro Line 1, opened in 1985, was the first subway outside of Seoul.",
  "Choryang Ibagu-gil contains Busan's modern history from Japanese occupation to post-war.",
  "Huinnyeoul Culture Village is famous as the filming location for the movie 'The Attorney'.",
  "Haeundae-gu is the only district in Korea with two major beaches (Haeundae, Songjeong).",
  "Busan Harbor Bridge is a night landmark with colorful lights changing every moment.",
  "Haedong Yonggungsa is one of Korea's most beautiful temples, built on a coastal cliff.",
  "Chinatown in front of Busan Station began at the site of the former Qing Consulate.",
  "Busan Tower in Yongdusan Park offers a panoramic view of the old city from 120m high."
];

const LoadingOverlay: React.FC<LoadingOverlayProps> = ({ districtName, lang }) => {
  const [triviaIdx, setTriviaIdx] = useState(0);
  const trivia = lang === 'ko' ? TRIVIA_KO : TRIVIA_EN;

  useEffect(() => {
    setTriviaIdx(Math.floor(Math.random() * trivia.length));
    
    const triviaInterval = setInterval(() => {
      setTriviaIdx((prev) => (prev + 1) % trivia.length);
    }, 4500); 
    return () => clearInterval(triviaInterval);
  }, [trivia.length]);

  return (
    <div className="fixed inset-0 z-[150] bg-white flex flex-col items-center justify-center px-6 md:px-12 overflow-hidden">
      {/* Background Wave Animation */}
      <div className="absolute bottom-0 left-0 w-full opacity-5 pointer-events-none">
        <svg viewBox="0 0 1440 320" className="w-full h-auto translate-y-20">
          <path fill="#2563eb" fillOpacity="1" d="M0,64L48,96C96,128,192,192,288,181.3C384,171,480,85,576,80C672,75,768,149,864,186.7C960,224,1056,224,1152,197.3C1248,171,1344,117,1392,90.7L1440,64L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
        </svg>
      </div>

      <div className="w-full max-w-4xl flex flex-col items-center text-center relative z-10">
        
        {/* Spinner - Optimized Size */}
        <div className="relative w-20 h-20 md:w-32 md:h-32 mb-8 md:mb-12 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-[5px] md:border-[8px] border-slate-50"></div>
          <div className="absolute inset-0 rounded-full border-[5px] md:border-[8px] border-blue-600 border-t-transparent animate-spin"></div>
          <div className="flex flex-col items-center">
            <span className="text-[10px] md:text-lg font-black text-slate-900 leading-none tracking-tighter uppercase">REAL</span>
            <span className="text-[6px] md:text-[9px] font-black text-blue-600 tracking-[0.2em] uppercase mt-1">Insight</span>
          </div>
        </div>

        <h2 className="text-3xl md:text-5xl lg:text-6xl font-black text-slate-900 mb-8 md:mb-12 tracking-tighter break-keep leading-tight drop-shadow-sm">
          {districtName} ⚓
        </h2>
        
        {/* Trivia Box - Scaled Down for Balance */}
        <div className="w-full mb-8 md:mb-12 max-w-3xl px-4">
          <div className="mb-5 flex flex-col items-center gap-2">
            <p className="text-[9px] md:text-[12px] font-black text-blue-600 uppercase tracking-[0.3em] opacity-90">
              {lang === 'ko' ? '현지의 생생한 목소리를 수집하는 중' : 'COLLECTING REAL LOCAL VOICES'}
            </p>
          </div>

          <div className="px-8 py-10 md:px-14 md:py-16 bg-slate-50 rounded-[24px] md:rounded-[40px] border border-slate-100 relative min-h-[140px] md:min-h-[200px] flex items-center justify-center shadow-inner overflow-hidden">
            <p key={`${lang}-${triviaIdx}`} className="text-slate-800 text-base md:text-xl lg:text-2xl font-bold leading-snug animate-in fade-in slide-in-from-bottom-2 duration-1000 break-keep max-w-[90%] px-2 z-10 relative">
              {trivia[triviaIdx]}
            </p>
            
            {/* Decorative corners - Subtle Scale */}
            <div className="absolute top-5 left-5 md:top-8 md:left-8 w-5 h-5 md:w-10 md:h-10 border-t-[2px] border-l-[2px] border-slate-200"></div>
            <div className="absolute bottom-5 right-5 md:bottom-8 md:right-8 w-5 h-5 md:w-10 md:h-10 border-b-[2px] border-r-[2px] border-slate-200"></div>
            
            {/* Watermark - Discrete Scale */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-slate-200/30 text-[5rem] md:text-[8rem] font-black pointer-events-none select-none z-0 opacity-10 uppercase">
               Busan
            </div>
          </div>
        </div>
        
        <div className="flex gap-3.5 items-center">
          <div className="w-1.5 h-1.5 md:w-2.5 md:h-2.5 rounded-full bg-blue-600 animate-bounce [animation-delay:-0.3s]"></div>
          <div className="w-1.5 h-1.5 md:w-2.5 md:h-2.5 rounded-full bg-blue-400 animate-bounce [animation-delay:-0.15s]"></div>
          <div className="w-1.5 h-1.5 md:w-2.5 md:h-2.5 rounded-full bg-blue-200 animate-bounce"></div>
        </div>
      </div>
    </div>
  );
};

export default LoadingOverlay;
