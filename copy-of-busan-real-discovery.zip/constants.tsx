
import { MapDistrict } from './types';

export const BUSAN_DISTRICTS: MapDistrict[] = [
  { id: 'gangseogu', nameKo: '강서구', nameEn: 'Gangseo', x: 80, y: 550, size: 85 },
  { id: 'bukgu', nameKo: '북구', nameEn: 'Buk-gu', x: 260, y: 250, size: 75 },
  { id: 'sasanggu', nameKo: '사상구', nameEn: 'Sasang', x: 260, y: 480, size: 70 },
  { id: 'sahagu', nameKo: '사하구', nameEn: 'Saha-gu', x: 220, y: 720, size: 75 },
  { id: 'geumjeong', nameKo: '금정구', nameEn: 'Geumjeong', x: 480, y: 120, size: 85 },
  { id: 'dongrae', nameKo: '동래구', nameEn: 'Dongrae', x: 480, y: 320, size: 75 },
  { id: 'yeonje', nameKo: '연제구', nameEn: 'Yeonje', x: 620, y: 400, size: 60 },
  { id: 'busanjingu', nameKo: '부산진구', nameEn: 'Busanjin', x: 420, y: 530, size: 85 },
  { id: 'suyeong', nameKo: '수영구', nameEn: 'Suyeong', x: 740, y: 520, size: 65 },
  { id: 'namgu', nameKo: '남구', nameEn: 'Nam-gu', x: 700, y: 720, size: 75 },
  { id: 'haeundae', nameKo: '해운대구', nameEn: 'Haeundae', x: 880, y: 450, size: 95 },
  { id: 'gijang', nameKo: '기장군', nameEn: 'Gijang', x: 920, y: 180, size: 105 },
  { id: 'donggu', nameKo: '동구', nameEn: 'Dong-gu', x: 480, y: 680, size: 60 },
  { id: 'junggu', nameKo: '중구', nameEn: 'Jung-gu', x: 400, y: 800, size: 50 },
  { id: 'seogu', nameKo: '서구', nameEn: 'Seo-gu', x: 320, y: 880, size: 60 },
  { id: 'yeongdo', nameKo: '영도구', nameEn: 'Yeongdo', x: 550, y: 880, size: 70 }
];
