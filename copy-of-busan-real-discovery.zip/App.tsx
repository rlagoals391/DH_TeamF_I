
import React, { useState, useRef } from 'react';
import BusanMap from './components/BusanMap';
import LoadingOverlay from './components/LoadingOverlay';
import DistrictDetail from './components/DistrictDetail';
import UsefulServices from './components/UsefulServices';
import FestivalSection from './components/FestivalSection';
import ExhibitionSection from './components/ExhibitionSection';
import CourseSection from './components/CourseSection';
import { fetchDistrictInsight } from './services/gemini';
import { MultiLangData, Language } from './types';
import { BUSAN_DISTRICTS } from './constants';

const App: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [lang, setLang] = useState<Language>('ko');
  const [selectedDistrict, setSelectedDistrict] = useState<{ko: string, en: string} | null>(null);
  const [reportData, setReportData] = useState<MultiLangData | null>(null);
  
  const cache = useRef<Record<string, MultiLangData>>({});

  const handleDistrictClick = async (districtId: string) => {
    const dist = BUSAN_DISTRICTS.find(d => d.id === districtId);
    if (!dist) {
      console.error("District not found:", districtId);
      return;
    }

    const names = { ko: dist.nameKo, en: dist.nameEn };
    
    if (cache.current[dist.id]) {
      setSelectedDistrict(names);
      setReportData(cache.current[dist.id]);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    setLoading(true);
    setSelectedDistrict(names);
    
    try {
      const data = await fetchDistrictInsight(dist.nameKo);
      cache.current[dist.id] = data;
      setReportData(data);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err) {
      console.error("AI Analysis Error:", err);
      alert(lang === 'ko' ? "데이터를 분석하는 중 오류가 발생했습니다. 다시 시도해주세요." : "An error occurred while analyzing data. Please try again.");
      setLoading(false);
      setSelectedDistrict(null);
    } finally {
      setLoading(false);
    }
  };

  const handleBackToMap = () => {
    setReportData(null);
    setSelectedDistrict(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen relative bg-white pb-20 md:pb-32 text-slate-900 selection:bg-blue-100 transition-colors duration-500 overflow-x-hidden">
      {/* Language Switcher */}
      <div className="fixed top-6 right-6 md:top-10 md:right-10 z-[400] flex items-center bg-white/95 backdrop-blur-xl p-1 rounded-full shadow-2xl border border-slate-100">
        <button 
          onClick={() => setLang('ko')}
          className={`px-5 md:px-8 py-2 md:py-3 rounded-full text-[10px] md:text-[13px] font-black tracking-widest transition-all ${lang === 'ko' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}
        >
          KR
        </button>
        <button 
          onClick={() => setLang('en')}
          className={`px-5 md:px-8 py-2 md:py-3 rounded-full text-[10px] md:text-[13px] font-black tracking-widest transition-all ${lang === 'en' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}
        >
          EN
        </button>
      </div>

      {!reportData && !loading && (
        <div className="w-full">
          {/* Header Section with Wave */}
          <header className="relative pt-24 md:pt-48 pb-24 md:pb-52 px-6 flex flex-col items-center text-center overflow-hidden mb-32 md:mb-52">
            <div className="absolute bottom-0 left-0 w-full opacity-10 pointer-events-none translate-y-10">
              <svg viewBox="0 0 1440 320" className="w-full h-auto scale-150 origin-bottom">
                <path fill="#2563eb" fillOpacity="1" d="M0,160L48,176C96,192,192,224,288,213.3C384,203,480,149,576,144C672,139,768,181,864,197.3C960,213,1056,203,1152,181.3C1248,160,1344,128,1392,112L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
              </svg>
            </div>

            <div className="max-w-[1200px] animate-in fade-in slide-in-from-top-4 duration-1000 relative z-10">
              <div className="inline-flex items-center gap-3 px-5 py-2 md:px-6 md:py-3 bg-slate-900 text-white text-[9px] md:text-[12px] font-black rounded-full mb-10 md:mb-16 tracking-[0.4em] md:tracking-[0.6em] uppercase shadow-2xl">
                  <span>⚓</span>
                  {lang === 'ko' ? '부산의 가치를 증명하는 기록' : 'PROVING THE VALUE OF BUSAN'}
                  <span>⚓</span>
              </div>
              <h1 className="text-5xl md:text-8xl lg:text-9xl font-black text-slate-900 tracking-tighter leading-[1.1] md:leading-[0.8] mb-10 md:mb-20 break-keep">
                {lang === 'ko' ? <>부산 🌊<br/><span className="text-blue-600">오리지널</span></> : <>busan 🌊<br/><span className="text-blue-600">original</span></>}
              </h1>
              <p className="text-lg md:text-2xl lg:text-4xl text-slate-400 font-bold max-w-4xl mx-auto leading-relaxed px-4 opacity-80">
                {lang === 'ko' 
                  ? '수식어의 거품이 걷힌 자리, 거친 파도가 빚어낸 이 도시의 가장 투명한 맥박을 기록합니다.' 
                  : 'Where the bubbles of adjectives have cleared, we record the most transparent pulse of this city shaped by rough waves.'}
              </p>
            </div>
          </header>

          {/* Spacing to Essential Utilities Section */}
          <UsefulServices lang={lang} />
          <FestivalSection lang={lang} />

          <section className="max-w-[1400px] mx-auto py-16 md:py-32 px-6 md:px-12">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-16 gap-6">
               <div className="max-w-3xl">
                  <h2 className="text-2xl md:text-5xl font-black tracking-tighter mb-4 leading-none">
                    {lang === 'ko' ? '지도로 마주하는 구역의 본질 ⛵' : 'Encountering the Essence on the Map ⛵'}
                  </h2>
                  <p className="text-slate-400 font-bold text-sm md:text-lg">
                    {lang === 'ko' ? '경계를 넘어 각 구역이 품고 있는 독보적인 가치를 확인하세요' : 'Cross the boundaries to discover the unique values held by each district'}
                  </p>
               </div>
            </div>
            <div className="bg-slate-50/50 p-4 md:p-16 lg:p-24 rounded-[60px] md:rounded-[100px] border border-slate-100 shadow-inner overflow-hidden relative">
              <BusanMap onDistrictClick={handleDistrictClick} lang={lang} />
            </div>
          </section>

          <CourseSection lang={lang} />
          <ExhibitionSection lang={lang} />
        </div>
      )}

      <main className="w-full">
        {loading ? (
          <LoadingOverlay districtName={selectedDistrict ? selectedDistrict[lang] : ""} lang={lang} />
        ) : reportData && (
          <DistrictDetail 
            data={reportData[lang]} 
            sources={reportData.sources}
            lang={lang} 
            onBack={handleBackToMap} 
          />
        )}
      </main>
    </div>
  );
};

export default App;
