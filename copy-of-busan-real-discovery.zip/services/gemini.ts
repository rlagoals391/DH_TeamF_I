
import { GoogleGenAI, Type } from "@google/genai";
import { MultiLangData, Landmark, Food, MichelinRestaurant } from "../types";

export async function fetchDistrictInsight(districtName: string): Promise<MultiLangData> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const systemInstruction = `You are a "Busan Docent" providing travel reports under the brand "Busan Original".

  [CRITICAL: DATA INTEGRITY]
  - Especially for Haeundae-gu, ensure the JSON is complete. If many items exist, prioritize the most famous ones.
  - The "address" field MUST be a real physical address (e.g., "62, Gu-nam-ro, Haeundae-gu, Busan"), NOT a URL.

  [CRITICAL: MAP ACCURACY]
  - For Map URLs, always use this template to ensure South Korea location:
    https://www.google.com/maps/search/?api=1&query=[PlaceName]+${districtName}+Busan+South+Korea
  - Use the most official and specific names.`;

  const prompt = `Generate an authoritative "Busan Original" report for "${districtName}" district in both Korean and English.
  
  Content:
  - 5 Landmarks, 5 Eateries.
  - Official Michelin Guide Busan entries.
  - Return PURE JSON object only.

  JSON Schema:
  {
    "ko": {
      "name": "구역 이름", "motto": "슬로건", "aiSummary": "요약",
      "landmarks": [{"name": "명소명", "description": "설명", "pos": "장점", "neg": "팁", "foreignerInfo": "외국인정보", "address": "실제주소"}],
      "foods": [{"name": "식당명", "description": "설명", "pos": "장점", "neg": "팁", "foreignerInfo": "외국인정보", "address": "실제주소", "bestMenu": "메뉴"}],
      "michelin": [{"name": "식당명", "type": "등급", "description": "설명", "foreignerInfo": "외국인정보", "address": "실제주소", "signature": "메뉴"}]
    },
    "en": {
      "name": "District", "motto": "Slogan", "aiSummary": "Summary",
      "landmarks": [{"name": "Name", "description": "Desc", "pos": "Pro", "neg": "Tip", "foreignerInfo": "Info", "address": "Physical Address"}],
      "foods": [{"name": "Name", "description": "Desc", "pos": "Pro", "neg": "Tip", "foreignerInfo": "Info", "address": "Physical Address", "bestMenu": "Menu"}],
      "michelin": [{"name": "Name", "type": "Type", "description": "Desc", "foreignerInfo": "Info", "address": "Physical Address", "signature": "Menu"}]
    }
  }`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview", 
      contents: prompt,
      config: {
        systemInstruction,
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json"
      }
    });

    let jsonText = response.text || '{}';
    jsonText = jsonText.replace(/```json|```/g, '').trim();
    
    const rawData = JSON.parse(jsonText);
    
    const processItems = (items: any[]) => {
      if (!items || !Array.isArray(items)) return [];
      return items.filter(item => item && (item.name || item.title)).map(item => {
        const name = item.name || item.title;
        // 더욱 정교해진 검색 쿼리: 장소명 + 구 + 부산 + 한국
        const searchQuery = encodeURIComponent(`${name} ${districtName} Busan South Korea`);
        return {
          ...item,
          name: name,
          address: item.address && !item.address.startsWith('http') ? item.address : `${districtName}, Busan`,
          mapUrl: `https://www.google.com/maps/search/?api=1&query=${searchQuery}`,
          photoSearchUrl: `https://www.google.com/search?tbm=isch&q=${searchQuery}`
        };
      });
    };

    return {
      ko: {
        ...rawData.ko,
        name: rawData.ko?.name || districtName,
        landmarks: processItems(rawData.ko?.landmarks),
        foods: processItems(rawData.ko?.foods),
        michelin: processItems(rawData.ko?.michelin)
      },
      en: {
        ...rawData.en,
        name: rawData.en?.name || districtName,
        landmarks: processItems(rawData.en?.landmarks),
        foods: processItems(rawData.en?.foods),
        michelin: processItems(rawData.en?.michelin)
      },
      sources: (response.candidates?.[0]?.groundingMetadata?.groundingChunks || [])
        .filter((c: any) => c.web).map((c: any) => ({ title: c.web.title, uri: c.web.uri })).slice(0, 5)
    };
  } catch (error) {
    console.error("AI Fetching Error:", error);
    throw error;
  }
}
