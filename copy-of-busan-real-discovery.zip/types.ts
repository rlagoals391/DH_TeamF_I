
export interface Landmark {
  name: string;
  description: string;
  pos: string;
  neg: string;
  address: string;
  mapUrl: string;
  photoSearchUrl: string;
  foreignerInfo?: string; // 채식 옵션, 영어 안내 등 외국인 대상 정보
}

export interface Food {
  name: string;
  description: string;
  pos: string;
  neg: string;
  address: string;
  mapUrl: string;
  photoSearchUrl: string;
  bestMenu: string;
  foreignerInfo?: string; // 채식 옵션, 영어 메뉴판 등 외국인 대상 정보
}

export interface MichelinRestaurant {
  name: string;
  type: 'Star' | 'Bib Gourmand' | 'Selected';
  description: string;
  address: string;
  signature: string;
  mapUrl: string;
  photoSearchUrl: string;
  foreignerInfo?: string;
}

export interface DistrictData {
  name: string;
  motto: string;
  aiSummary: string;
  landmarks: Landmark[];
  foods: Food[];
  michelin: MichelinRestaurant[];
}

export interface MultiLangData {
  ko: DistrictData;
  en: DistrictData;
  sources: Array<{ title: string; uri: string }>;
}

export interface MapDistrict {
  id: string;
  nameKo: string;
  nameEn: string;
  x: number;
  y: number;
  size: number;
}

export type Language = 'ko' | 'en';
